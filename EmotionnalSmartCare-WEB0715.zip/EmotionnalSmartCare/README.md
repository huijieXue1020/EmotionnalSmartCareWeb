# IntelligentCareSystem_WEB
情感智能看护系统前端部分

其他仓库链接：

计算机视觉git:  https://github.com/dbylx/IntelligentCareSystem_CV

后端git: https://github.com/litterboyDeng/IntelligentCareSystem

